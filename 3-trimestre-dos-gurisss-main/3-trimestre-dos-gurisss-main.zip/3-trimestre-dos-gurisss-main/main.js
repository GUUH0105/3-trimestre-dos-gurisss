document.querySelector('.tecla_pom').onclick = tocaSompom;
document.querySelector('.tecla_clap').onclick = tocaSomclap;
document.querySelector('.tecla_tim').onclick = tocaSomtim;
document.querySelector('.tecla_puff').onclick = tocaSompuff;
document.querySelector('.tecla_splash').onclick = tocaSomsplash;
document.querySelector('.tecla_toim').onclick = tocaSomtoim;
document.querySelector('.tecla_psh').onclick = tocaSompsh;
document.querySelector('.tecla_tic').onclick = tocaSomtic;
document.querySelector('.tecla_tom').onclick = tocaSomtom;



function tocaSompom(){
    document.querySelector('#som_tecla_pom').play();
}
function tocaSomclap(){
    document.querySelector('#som_tecla_clap').play();
}

function tocaSomtim(){
    document.querySelector('#som_tecla_tim').play();
}

function tocaSompuff(){
    document.querySelector('#som_tecla_puff').play();
}

function tocaSomsplash(){
    document.querySelector('#som_tecla_splash').play();
}
function tocaSomtoim(){
    document.querySelector('#som_tecla_toim').play();
}
function tocaSompsh(){
    document.querySelector('#som_tecla_psh').play();
}
function tocaSomtic(){
    document.querySelector('#som_tecla_tic').play();
}
function tocaSomtom(){
    document.querySelector('#som_tecla_tom').play();
}
